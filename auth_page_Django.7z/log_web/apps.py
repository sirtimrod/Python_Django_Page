from django.apps import AppConfig


class LogWebConfig(AppConfig):
    name = 'log_web'